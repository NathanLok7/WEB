import express from 'express';
import chalk from 'chalk';
import fs from 'fs';
const axios = require('axios');

const app = express();
const port = 3000;

app.use(express.json());

function queryParam(id) {
  let url = "http://localhost:3000/productos?id=" + id;
  axios.get(url)
    .then(response => {
        let producto = response.data;
        if (producto.length > 0) {
            console.log("Producto encontrado. ");
            let prd = `
              <b>Producto: </b>
              <p>Producto: ${producto[0].name}</p>
              <p>Precio: ${producto[0].price}</p>
            `;
             console.log(prd);
        }else {
          console.log("Producto no encontrado. ");
        }
    })
}
queryParam(1);


app.get('/showProducts', (req, res) => {
    let url = "http://localhost:3000/productos";
    let xhr = new XMLHttpRequest();
    xhr.open('GET', url);
    xhr.send();
    xhr.onload = function () {
        if(xhr.status != 200){
            console.error(chalk.red("Error al obtener los productos: " + xhr.statusText));
            res.status(xhr.status).send(xhr.statusText);
            return;
          }
        const products = JSON.parse(xhr.responseText);
        console.log(chalk.green("Productos encontrados. "));
        console.table(products);
        let htmlOutput = '<h1>Productos</h1>';
        products.forEach(product => {
            htmlOutput += `<b>Producto ${product.id}:</b>
                            <p>Nombre: ${product.name}</p>
                            <p>Precio: $${product.precio}</p>
                            <p>Categoría: ${product.category}</p>
                            <p>Descripción: ${product.description}</p>
                            <p>Stock: ${product.stock}</p><br>`;
        });
        res.send(htmlOutput);
    };
});


app.get('/product', (req, res) => {
    const productName = req.query.name;
    let url = "http://localhost:3000/productos?name=" + productName;
    let xhr = new XMLHttpRequest();
    xhr.open('GET', url);
    xhr.send();
    xhr.onload = function () {
        if(xhr.status != 200){
            console.error(chalk.red("Error al obtener el producto: " + xhr.statusText));
            res.status(xhr.status).send(xhr.statusText);
            return;
        }
        const products = JSON.parse(xhr.responseText);
        const productFound = products[0]; 
        if(productFound){
            let htmlOutput = `<h1>Producto Encontrado</h1>
                              <p>Nombre: ${productFound.name}</p>
                              <p>Precio: $${productFound.price}</p>`;
            res.send(htmlOutput);
        } {
            res.send("Producto no encontrado.");
        }
    };
});

app.listen(port, () => {
    console.log("Puerto:",  ${port});
});
