const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");

const app = express();
const port = 3000;

app.use(express.json());

app.use(
    cors({
        methods: ["GET", "POST", "DELETE", "UPDATE", "PUT", "PATCH"],
    })
);

const mongoConnection = "mongodb+srv://admin:admin@myapp.mfg5ynr.mongodb.net";

mongoose.connect(mongoConnection, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

const db = mongoose.connection;

db.on("error", (error) => {
    console.error("Error de conexión a la base de datos:", error);
});

db.once("open", () => {
    console.log("Conexión a la base de datos establecida");
});

const userSchema = new mongoose.Schema({
    Nombre:{
        type: String,
        required: true,
    },
    Correo:{
        type: String,
        required: true,
    },
    Pass:{
        type: String,
        required: true,
    },
    Edad:{
        type: Number,
        min: 0,
        max: 120,
        required: true,
    },
    Sexo:{
        type: String,
        enum: ["F", "M"],
        required: true,
    },
});

const User = mongoose.model("User", userSchema);

app.post("/api/users", async (req, res) => {
    try{
        const userData = req.body;
        const newUser = new User(userData);
        const savedUser = await newUser.save();
        console.log("Usuario ha sido creado: " + doc);
        res.json(savedUser);
    }catch (error) {
        res.status(500).json({ error:"No se pudo crear el usuario." });
    }
});

app.listen(port, () => {
    console.log("Aplicación en ejecución en el puerto " + port);
});
